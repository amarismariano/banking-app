import axios from "axios";

axios.defaults.baseURL = "http://localhost:5000"; // Cambia esta URL según tu backend

export default axios;
