require("dotenv").config({ path: ".env.test" });
const request = require("supertest");
const app = require("../../server"); // Your express app entry file
const mongoose = require("mongoose");
const Payment = require("../../models/payment.model");
const User = require("../../models/user.model");

let token;

beforeAll(async () => {
  // Clear users collection
  await User.deleteMany();

  // Create a user for authentication
  const user = await User.create({
    username: "testuser21",
    password: "testpassword",
  });

  // Simulate login to obtain an authentication token
  const res = await request(app).post("/api/auth/login").send({
    username: "testuser21",
    password: "testpassword",
  });

  token = res.body.token; // Store the token to use in tests
});

afterAll(async () => {
  // Clear payment and user data after all tests
  await Payment.deleteMany();
  await User.deleteMany();
  await mongoose.connection.close(); // Close the database connection
});

describe("Payment API", () => {
  // Test for creating a payment
  describe("POST /payments", () => {
    it("should create a new payment", async () => {
      const paymentData = { amount: 100, description: "Test payment" };

      const res = await request(app)
        .post("/payments")
        .send(paymentData)
        .set("Authorization", `Bearer ${token}`); // Use the token in the header

      expect(res.statusCode).toEqual(201);
      expect(res.body).toHaveProperty("amount", paymentData.amount);
      expect(res.body).toHaveProperty("description", paymentData.description);
    });

    it("should fail if no authentication token is provided", async () => {
      const paymentData = { amount: 100, description: "Payment without token" };

      const res = await request(app).post("/payments").send(paymentData);

      expect(res.statusCode).toEqual(401);
      expect(res.body).toHaveProperty("error");
    });
  });

  // Test for getting payments
  describe("GET /payments", () => {
    it("should get all payments for the authenticated user", async () => {
      const res = await request(app)
        .get("/payments")
        .set("Authorization", `Bearer ${token}`);

      expect(res.statusCode).toEqual(200);
      expect(Array.isArray(res.body)).toBe(true); // Verify response is an array
    });

    it("should fail if no authentication token is provided", async () => {
      const res = await request(app).get("/payments");

      expect(res.statusCode).toEqual(401);
      expect(res.body).toHaveProperty("error");
    });
  });

  // Test for updating a payment
  describe("PUT /payments/:id", () => {
    let paymentId;

    beforeAll(async () => {
      // Create a sample payment to update
      const payment = await Payment.create({
        amount: 100,
        description: "Payment to update",
        user: mongoose.Types.ObjectId(), // Simulate a user
      });
      paymentId = payment._id;
    });

    it("should update an existing payment", async () => {
      const updatedData = { amount: 150, description: "Updated payment" };

      const res = await request(app)
        .put(`/payments/${paymentId}`)
        .send(updatedData)
        .set("Authorization", `Bearer ${token}`);

      expect(res.statusCode).toEqual(200);
      expect(res.body).toHaveProperty("amount", updatedData.amount);
      expect(res.body).toHaveProperty("description", updatedData.description);
    });

    it("should return an error if the payment does not exist", async () => {
      const res = await request(app)
        .put(`/payments/invalidid`)
        .set("Authorization", `Bearer ${token}`);

      expect(res.statusCode).toEqual(400);
    });
  });

  // Test for deleting a payment
  describe("DELETE /payments/:id", () => {
    let paymentId;

    beforeAll(async () => {
      // Create a payment to delete
      const payment = await Payment.create({
        amount: 200,
        description: "Payment to delete",
        user: mongoose.Types.ObjectId(),
      });
      paymentId = payment._id;
    });

    it("should delete an existing payment", async () => {
      const res = await request(app)
        .delete(`/payments/${paymentId}`)
        .set("Authorization", `Bearer ${token}`);

      expect(res.statusCode).toEqual(200);
      expect(res.body).toHaveProperty("message", "Payment deleted");
    });

    it("should return an error if the payment does not exist", async () => {
      const res = await request(app)
        .delete(`/payments/invalidid`)
        .set("Authorization", `Bearer ${token}`);

      expect(res.statusCode).toEqual(404);
      expect(res.body).toHaveProperty("error", "Payment not found");
    });
  });
});
